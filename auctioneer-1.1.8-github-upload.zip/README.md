# Auctioneer 1.1.8

A client-side auction timer and highest-bid overlay for Minecraft 26.2.

## Changes in 1.1.8

- Returned the main controls and HUD to Minecraft's own UI and renderer; no separate desktop window is opened.
- Removed the upper-left "SA" badge and renamed the interface to **Auctioneer**.
- Restored the selected item's Minecraft texture and the circular timer ring in the main menu and HUD.
- Removed the left-side Items tab. Select an item by clicking the item preview and searching in the in-game item picker.
- Kept black/purple styling, duration settings, optional minimum payment, highest bidder only, the HUD toggle, and the small bottom-left "Made by SlachlanS" watermark.
- Uses the bundled Exo 2 font through Minecraft's font-resource system. The provider references `streamauction:exo2.ttf`.

## Features

- Set a duration from 5 to 3,600 seconds.
- Optional minimum payment such as `250k` or `1.5m`; smaller payments are ignored completely. Leave blank to count all positive payments.
- Choose items with their Minecraft item textures from a searchable picker. Spawn eggs and operator-only items are filtered out.
- Minimal HUD: selected item, countdown, highest bidder, their total, and the subtle watermark.
- Right Shift opens the in-game Auctioneer menu.
- Only server/system payment notices are parsed; ordinary player chat is ignored.
- Settings and results are stored locally in `config/streamauction/state.json`.

## Read-only behavior

The mod sends no commands or chat messages, does not click game menus, manipulate inventory, move the player, or place bids. It makes no web requests and does not access authentication tokens.

## DonutSMP rules

Official rules: https://rules.donutsmp.net/. The rules mention prohibited economy-related scripts involving auctions or markets. This mod is designed as a passive message reader, but the rules do not explicitly guarantee that a streamer-hosted auction tracker is exempt. Ask DonutSMP staff to approve this exact read-only use before using it on the server. No mod can guarantee zero ban risk.

## Build

Requirements: Windows, Java 25 JDK, Minecraft 26.2, Fabric Loader 0.19.5+, and Fabric API 0.161.0+26.2.

Run from this directory in PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

The compiled mod is created at `build/libs/streamauctionboard-1.1.8.jar`.

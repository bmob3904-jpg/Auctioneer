package dev.streamauction;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PaymentLedgerTest {
    @Test
    void ignoresPaymentsOutsideAnActiveAuction() {
        PaymentLedger ledger = new PaymentLedger();

        assertFalse(ledger.record(false, "PlayerA", 500_000L, 1_000L));
        assertEquals(0, ledger.paymentCount());
        assertEquals(0, ledger.bidderCount());
    }

    @Test
    void combinesRepeatedPaymentsForTheSameUsername() {
        PaymentLedger ledger = new PaymentLedger();

        assertTrue(ledger.record(true, "PlayerA", 500_000L, 1_000L));
        assertTrue(ledger.record(true, "playera", 250_000L, 2_000L));

        assertEquals(2, ledger.paymentCount());
        assertEquals(1, ledger.bidderCount());
        assertEquals(750_000L, ledger.leaderboard().getFirst().total());
        assertEquals(2, ledger.leaderboard().getFirst().paymentCount());
    }

    @Test
    void sortsByTotalAndReturnsAllTiedLeaders() {
        PaymentLedger ledger = new PaymentLedger();

        ledger.record(true, "Alex", 100_000L, 1_000L);
        ledger.record(true, "Blake", 200_000L, 2_000L);
        ledger.record(true, "Casey", 200_000L, 3_000L);

        assertEquals("Casey", ledger.leaderboard().getFirst().name());
        assertEquals(2, ledger.tiedLeaders().size());
        assertTrue(ledger.tiedLeaders().stream().allMatch(entry -> entry.total() == 200_000L));
    }

    @Test
    void ignoresPaymentsBelowOptionalMinimumWithoutCountingThem() {
        PaymentLedger ledger = new PaymentLedger();

        assertFalse(ledger.record(true, "SmallBidder", 249_999L, 250_000L, 1_000L));
        assertEquals(0, ledger.paymentCount());
        assertEquals(0, ledger.bidderCount());

        assertTrue(ledger.record(true, "QualifyingBidder", 250_000L, 250_000L, 2_000L));
        assertTrue(ledger.record(true, "QualifyingBidder", 500_000L, 250_000L, 3_000L));
        assertFalse(ledger.record(true, "QualifyingBidder", 1L, 250_000L, 4_000L));
        assertEquals(2, ledger.paymentCount());
        assertEquals(1, ledger.bidderCount());
        assertEquals(750_000L, ledger.leaderboard().getFirst().total());
        assertEquals(2, ledger.leaderboard().getFirst().paymentCount());
    }

    @Test
    void rejectsInvalidPaymentsAndSaturatesOverflow() {
        PaymentLedger ledger = new PaymentLedger();

        assertFalse(ledger.record(true, " ", 100L, 1_000L));
        assertFalse(ledger.record(true, "Alex", 0L, 1_000L));
        assertFalse(ledger.record(true, null, 100L, 1_000L));
        ledger.record(true, "Alex", Long.MAX_VALUE, 2_000L);
        ledger.record(true, "Alex", 100L, 3_000L);

        assertEquals(Long.MAX_VALUE, ledger.leaderboard().getFirst().total());
    }
}

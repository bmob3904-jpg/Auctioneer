﻿$ErrorActionPreference = 'Stop'
$requiredJava = 25

$javaExe = $null
if ($env:JAVA_HOME) {
    $candidate = Join-Path $env:JAVA_HOME 'bin\java.exe'
    if (Test-Path $candidate) { $javaExe = $candidate }
}
if (-not $javaExe) {
    $command = Get-Command java -ErrorAction SilentlyContinue
    if ($command) { $javaExe = $command.Source }
}
if (-not $javaExe) {
    throw 'Java was not found. Set JAVA_HOME to a Java 25 JDK and retry.'
}

$oldPreference = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$versionOutput = (& $javaExe -version 2>&1 | Out-String)
$ErrorActionPreference = $oldPreference
if ($versionOutput -notmatch 'version "?(?<major>\d+)') {
    throw 'Could not read the Java version. Install or select a Java 25 JDK.'
}
$javaMajor = [int]$Matches['major']
if ($javaMajor -lt $requiredJava) {
    throw "Minecraft 26.2 requires Java 25. Detected Java $javaMajor."
}

$gradleVersion = '9.7.0'
$toolsDir = Join-Path $PSScriptRoot '.tools'
$gradleHome = Join-Path $toolsDir "gradle-$gradleVersion"
$gradleZip = Join-Path $toolsDir "gradle-$gradleVersion-bin.zip"
New-Item -ItemType Directory -Force -Path $toolsDir | Out-Null

if (-not (Test-Path (Join-Path $gradleHome 'bin\gradle.bat'))) {
    $url = "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip"
    Write-Host "Downloading Gradle $gradleVersion..."
    & curl.exe -L --fail --retry 2 --max-time 300 -sS -o $gradleZip $url
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $gradleZip)) {
        throw 'Could not download Gradle. Check your connection and retry.'
    }
    Expand-Archive -LiteralPath $gradleZip -DestinationPath $toolsDir -Force
    Remove-Item $gradleZip -Force
}

$gradleBat = Join-Path $gradleHome 'bin\gradle.bat'
Write-Host "Using Java $javaMajor"
& $gradleBat --no-daemon clean build
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}

Write-Host ''
Write-Host 'Build and tests completed. Mod JAR:'
Get-ChildItem (Join-Path $PSScriptRoot 'build\libs') -Filter '*.jar' |
    Where-Object { $_.Name -notlike '*-sources.jar' } |
    ForEach-Object { Write-Host $_.FullName }


/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.core.registries.BuiltInRegistries
 *  net.minecraft.resources.Identifier
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Items
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package dev.streamauction;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.streamauction.PaymentLedger;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class AuctionManager {
    private static final Logger LOGGER = LoggerFactory.getLogger((String)"streamauction");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path DIRECTORY = FabricLoader.getInstance().getConfigDir().resolve("streamauction");
    private static final Path STATE_FILE = DIRECTORY.resolve("state.json");
    private static boolean active;
    private static boolean finished;
    private static boolean interrupted;
    private static boolean hudVisible;
    private static int durationSeconds;
    private static long minimumPaymentAmount;
    private static String selectedItemId;
    private static long startedAtMillis;
    private static long endsAtMillis;
    private static long finishedAtMillis;
    private static final PaymentLedger LEDGER;
    private static String finishMessage;
    private static String lastPaymentName;
    private static long lastPaymentAmount;

    private AuctionManager() {
    }

    public static synchronized void load() {
        try {
            Files.createDirectories(DIRECTORY, new FileAttribute[0]);
            if (!Files.exists(STATE_FILE, new LinkOption[0])) {
                AuctionManager.save();
                return;
            }
            StateData data = (StateData)GSON.fromJson(Files.readString(STATE_FILE), StateData.class);
            if (data == null) {
                return;
            }
            durationSeconds = AuctionManager.clamp(data.durationSeconds, 5, 3600);
            minimumPaymentAmount = Math.max(0L, data.minimumPaymentAmount);
            hudVisible = data.hudVisible;
            selectedItemId = data.selectedItemId == null ? "minecraft:diamond" : data.selectedItemId;
            startedAtMillis = data.startedAtMillis;
            endsAtMillis = data.endsAtMillis;
            finishedAtMillis = data.finishedAtMillis;
            finishMessage = data.finishMessage == null ? "" : data.finishMessage;
            lastPaymentName = data.lastPaymentName == null ? "" : data.lastPaymentName;
            lastPaymentAmount = Math.max(0L, data.lastPaymentAmount);
            LEDGER.restore(data.bidders, Math.max(0, data.paymentCount));
            if (data.active) {
                active = false;
                finished = true;
                interrupted = true;
                finishMessage = "Stopped after restart - no winner declared";
                endsAtMillis = 0L;
            } else {
                active = false;
                finished = data.finished;
                interrupted = data.interrupted;
            }
            AuctionManager.selectedItem();
            AuctionManager.save();
        }
        catch (Exception exception) {
            LOGGER.error("Could not load Stream Auction Board state; starting with defaults", (Throwable)exception);
            active = false;
            finished = false;
            interrupted = false;
        }
    }

    public static synchronized void tick() {
        if (active && System.currentTimeMillis() >= endsAtMillis) {
            AuctionManager.finishAuction();
        }
    }

    public static synchronized boolean startAuction() {
        if (active) {
            return false;
        }
        AuctionManager.selectedItem();
        LEDGER.clear();
        lastPaymentName = "";
        lastPaymentAmount = 0L;
        startedAtMillis = System.currentTimeMillis();
        endsAtMillis = startedAtMillis + (long)durationSeconds * 1000L;
        finishedAtMillis = 0L;
        active = true;
        finished = false;
        interrupted = false;
        finishMessage = "";
        AuctionManager.save();
        return true;
    }

    public static synchronized void endAuction() {
        if (active) {
            AuctionManager.finishAuction();
        }
    }

    private static void finishAuction() {
        active = false;
        finished = true;
        interrupted = false;
        finishedAtMillis = System.currentTimeMillis();
        List<BidderSnapshot> ranking = AuctionManager.leaderboard();
        if (ranking.isEmpty()) {
            finishMessage = "Auction ended - no qualifying payments";
        } else {
            long topTotal = ranking.get(0).total();
            List<String> leaders = ranking.stream().filter(entry -> entry.total() == topTotal).map(BidderSnapshot::name).toList();
            finishMessage = leaders.size() == 1 ? "Winner: " + leaders.get(0) + " - " + AuctionManager.formatMoney(topTotal) : "Tie: " + String.join((CharSequence)", ", leaders) + " - " + AuctionManager.formatMoney(topTotal);
        }
        endsAtMillis = 0L;
        AuctionManager.save();
    }

    public static synchronized boolean recordPayment(String playerName, long amount) {
        AuctionManager.tick();
        long now = System.currentTimeMillis();
        if (!LEDGER.record(active, playerName, amount, minimumPaymentAmount, now)) {
            return false;
        }
        lastPaymentName = playerName.trim();
        lastPaymentAmount = amount;
        AuctionManager.save();
        return true;
    }

    public static synchronized void setDurationSeconds(int seconds) {
        durationSeconds = AuctionManager.clamp(seconds, 5, 3600);
        AuctionManager.save();
    }

    public static synchronized void setMinimumPaymentAmount(long amount) {
        minimumPaymentAmount = Math.max(0L, amount);
        AuctionManager.save();
    }

    public static synchronized long minimumPaymentAmount() {
        return minimumPaymentAmount;
    }

    public static synchronized void setSelectedItem(Item item) {
        if (item == null) {
            return;
        }
        selectedItemId = BuiltInRegistries.ITEM.getKey(item).toString();
        AuctionManager.save();
    }

    public static synchronized Item selectedItem() {
        Item item;
        Identifier id = Identifier.tryParse((String)selectedItemId);
        Item item2 = item = id == null ? null : (Item)BuiltInRegistries.ITEM.getValue(id);
        if (item == null || item == Items.AIR) {
            item = Items.DIAMOND;
            selectedItemId = BuiltInRegistries.ITEM.getKey(item).toString();
        }
        return item;
    }

    public static synchronized String selectedItemName() {
        Item item = AuctionManager.selectedItem();
        return item.getName(item.getDefaultInstance()).getString();
    }

    public static synchronized String selectedItemId() {
        return selectedItemId;
    }

    public static synchronized int durationSeconds() {
        return durationSeconds;
    }

    public static synchronized boolean isActive() {
        return active;
    }

    public static synchronized boolean isFinished() {
        return finished;
    }

    public static synchronized boolean wasInterrupted() {
        return interrupted;
    }

    public static synchronized boolean isHudVisible() {
        return hudVisible;
    }

    public static synchronized int paymentCount() {
        return LEDGER.paymentCount();
    }

    public static synchronized int bidderCount() {
        return LEDGER.bidderCount();
    }

    public static synchronized String finishMessage() {
        return finishMessage;
    }

    public static synchronized String lastPaymentName() {
        return lastPaymentName;
    }

    public static synchronized long lastPaymentAmount() {
        return lastPaymentAmount;
    }

    public static synchronized long finishedAtMillis() {
        return finishedAtMillis;
    }

    public static synchronized long secondsRemaining() {
        if (!active) {
            return 0L;
        }
        long remaining = endsAtMillis - System.currentTimeMillis();
        return Math.max(0L, (remaining + 999L) / 1000L);
    }

    public static synchronized void toggleHud() {
        hudVisible = !hudVisible;
        AuctionManager.save();
    }

    public static synchronized List<BidderSnapshot> leaderboard() {
        return LEDGER.leaderboard().stream().map(entry -> new BidderSnapshot(entry.name(), entry.total(), entry.paymentCount(), entry.lastPaymentAt(), entry.lastPaymentAmount())).toList();
    }

    public static synchronized List<BidderSnapshot> tiedLeaders() {
        return LEDGER.tiedLeaders().stream().map(entry -> new BidderSnapshot(entry.name(), entry.total(), entry.paymentCount(), entry.lastPaymentAt(), entry.lastPaymentAmount())).toList();
    }

    public static String formatMoney(long value) {
        long safe = Math.max(0L, value);
        if (safe < 1000L) {
            return String.format(Locale.US, "%,d", safe);
        }
        if (safe < 1000000L) {
            return AuctionManager.compact(safe, 1000.0, "K");
        }
        if (safe < 1000000000L) {
            return AuctionManager.compact(safe, 1000000.0, "M");
        }
        if (safe < 1000000000000L) {
            return AuctionManager.compact(safe, 1.0E9, "B");
        }
        return AuctionManager.compact(safe, 1.0E12, "T");
    }

    private static String compact(long value, double divisor, String suffix) {
        double quantity = (double)value / divisor;
        if (quantity >= 100.0) {
            return String.format(Locale.US, "%.0f%s", quantity, suffix);
        }
        if (quantity >= 10.0) {
            return String.format(Locale.US, "%.1f%s", quantity, suffix);
        }
        return String.format(Locale.US, "%.2f%s", quantity, suffix).replaceAll("0+([A-Z])$", "$1").replaceAll("\\.([A-Z])$", "$1");
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static void save() {
        try {
            Files.createDirectories(DIRECTORY, new FileAttribute[0]);
            StateData data = new StateData();
            data.active = active;
            data.finished = finished;
            data.interrupted = interrupted;
            data.hudVisible = hudVisible;
            data.durationSeconds = durationSeconds;
            data.minimumPaymentAmount = minimumPaymentAmount;
            data.selectedItemId = selectedItemId;
            data.startedAtMillis = startedAtMillis;
            data.endsAtMillis = endsAtMillis;
            data.finishedAtMillis = finishedAtMillis;
            data.paymentCount = LEDGER.paymentCount();
            data.finishMessage = finishMessage;
            data.lastPaymentName = lastPaymentName;
            data.lastPaymentAmount = lastPaymentAmount;
            data.bidders = LEDGER.entriesForSave();
            Path tempFile = DIRECTORY.resolve("state.json.tmp");
            Files.writeString(tempFile, (CharSequence)GSON.toJson((Object)data), new OpenOption[0]);
            try {
                Files.move(tempFile, STATE_FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            }
            catch (IOException ignored) {
                Files.move(tempFile, STATE_FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        }
        catch (Exception exception) {
            LOGGER.error("Could not save Stream Auction Board state", (Throwable)exception);
        }
    }

    static {
        hudVisible = true;
        durationSeconds = 60;
        minimumPaymentAmount = 0L;
        selectedItemId = "minecraft:diamond";
        LEDGER = new PaymentLedger();
        finishMessage = "";
        lastPaymentName = "";
    }

    private static final class StateData {
        private boolean active;
        private boolean finished;
        private boolean interrupted;
        private boolean hudVisible = true;
        private int durationSeconds = 60;
        private long minimumPaymentAmount;
        private String selectedItemId = "minecraft:diamond";
        private long startedAtMillis;
        private long endsAtMillis;
        private long finishedAtMillis;
        private int paymentCount;
        private String finishMessage = "";
        private String lastPaymentName = "";
        private long lastPaymentAmount;
        private Map<String, PaymentLedger.Bidder> bidders = new LinkedHashMap<String, PaymentLedger.Bidder>();

        private StateData() {
        }
    }

    public record BidderSnapshot(String name, long total, int paymentCount, long lastPaymentAt, long lastPaymentAmount) {
    }
}


package dev.streamauction;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;

public final class ItemPickerScreen extends Screen {
    private static final int MAX_WIDTH = 438;
    private static final int MAX_HEIGHT = 306;

    private final Screen parent;
    private final String query;
    private final int page;
    private EditBox searchField;
    private List<Item> filteredItems = List.of();
    private int displayPage;
    private int pageCount = 1;

    public ItemPickerScreen(Screen parent, String query, int page) {
        super(Component.literal("Auctioneer - Choose item"));
        this.parent = parent;
        this.query = query == null ? "" : query;
        this.page = Math.max(0, page);
    }

    private int panelWidth() { return Math.max(1, Math.min(MAX_WIDTH, this.width - 16)); }
    private int panelHeight() { return Math.max(1, Math.min(MAX_HEIGHT, this.height - 16)); }
    private int left() { return (this.width - this.panelWidth()) / 2; }
    private int top() { return (this.height - this.panelHeight()) / 2; }
    private int rowsPerPage() { return Math.max(1, Math.min(5, (this.panelHeight() - 146) / 29)); }
    private int pageSize() { return this.rowsPerPage() * 2; }

    @Override
    protected void init() {
        int left = this.left();
        int top = this.top();
        int width = this.panelWidth();
        int height = this.panelHeight();
        int innerX = left + 14;
        int innerWidth = width - 28;
        int searchY = top + 44;
        int searchButtonWidth = 82;
        int searchWidth = innerWidth - searchButtonWidth - 8;

        this.addRenderableWidget(new ModernButton(left + width - 32, top + 10, 22, 22,
                "X", AuctionUi.MUTED, false, this::closeToParent));

        this.searchField = new EditBox(AuctionUi.font(), innerX + 9, searchY + 5,
                searchWidth - 18, 18, Component.literal("Item name"));
        this.searchField.setMaxLength(80);
        this.searchField.setValue(this.query);
        this.searchField.setBordered(false);
        this.searchField.setTextColor(AuctionUi.WHITE);
        this.addRenderableWidget(this.searchField);

        this.addRenderableWidget(new ModernButton(innerX + searchWidth + 8, searchY + 1,
                searchButtonWidth, 26, "SEARCH", AuctionUi.PURPLE_BRIGHT, true, () ->
                    this.minecraft.gui.setScreen(new ItemPickerScreen(
                            this.parent, this.searchField.getValue().trim(), 0))));

        this.filteredItems = filterItems(this.query);
        this.pageCount = Math.max(1, (this.filteredItems.size() + this.pageSize() - 1) / this.pageSize());
        this.displayPage = Math.min(this.page, this.pageCount - 1);
        int startIndex = this.displayPage * this.pageSize();
        int columnWidth = (innerWidth - 8) / 2;

        for (int i = 0; i < this.pageSize() && startIndex + i < this.filteredItems.size(); i++) {
            Item item = this.filteredItems.get(startIndex + i);
            int column = i % 2;
            int row = i / 2;
            int buttonX = innerX + column * (columnWidth + 8);
            int buttonY = top + 80 + row * 29;
            String label = item.getName(item.getDefaultInstance()).getString();
            boolean selected = BuiltInRegistries.ITEM.getKey(item).toString()
                    .equals(AuctionManager.selectedItemId());
            this.addRenderableWidget(new ModernButton(buttonX, buttonY, columnWidth, 26,
                    label, null, item.getDefaultInstance(), false, null, null,
                    selected ? AuctionUi.PURPLE_BRIGHT : AuctionUi.BORDER, selected, () -> {
                        AuctionManager.setSelectedItem(item);
                        this.minecraft.gui.setScreen(this.parent);
                    }));
        }

        int footerY = top + height - 35;
        this.addRenderableWidget(new ModernButton(innerX, footerY, 88, 25,
                "PREV", AuctionUi.MUTED, false, () ->
                    this.minecraft.gui.setScreen(new ItemPickerScreen(
                            this.parent, this.query, Math.max(0, this.displayPage - 1)))));
        this.addRenderableWidget(new ModernButton(left + (width - 94) / 2, footerY, 94, 25,
                "CANCEL", AuctionUi.MUTED, false, this::closeToParent));
        this.addRenderableWidget(new ModernButton(left + width - 102, footerY, 88, 25,
                "NEXT", AuctionUi.PURPLE_BRIGHT, false, () ->
                    this.minecraft.gui.setScreen(new ItemPickerScreen(
                            this.parent, this.query, Math.min(this.pageCount - 1, this.displayPage + 1)))));
    }

    private static List<Item> filterItems(String query) {
        String needle = query == null ? "" : query.toLowerCase(Locale.ROOT).trim();
        ArrayList<Item> all = new ArrayList<>();
        for (Item item : BuiltInRegistries.ITEM) {
            String id = BuiltInRegistries.ITEM.getKey(item).toString();
            if (!ItemSelectionPolicy.isSelectable(id)) continue;
            String name = item.getName(item.getDefaultInstance()).getString().toLowerCase(Locale.ROOT);
            if (needle.isEmpty() || name.contains(needle)) all.add(item);
        }
        all.sort(Comparator.comparing(
                item -> item.getName(item.getDefaultInstance()).getString(),
                String.CASE_INSENSITIVE_ORDER));
        return all;
    }

    private void closeToParent() {
        if (this.minecraft != null) this.minecraft.gui.setScreen(this.parent);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == 256) {
            this.closeToParent();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean shouldCloseOnEsc() { return true; }

    @Override
    public void onClose() { this.closeToParent(); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        int left = this.left();
        int top = this.top();
        int width = this.panelWidth();
        int height = this.panelHeight();
        int innerX = left + 14;
        int innerWidth = width - 28;
        int searchY = top + 44;
        int searchWidth = innerWidth - 90;

        AuctionUi.drawBackdrop(graphics, this.width, this.height);
        AuctionUi.drawPanel(graphics, left, top, width, height);

        AuctionUi.drawText(graphics, "AUCTIONEER", left + 18, top + 14, AuctionUi.WHITE, true);
        AuctionUi.drawText(graphics, "CHOOSE ITEM", left + 18, top + 29, AuctionUi.MUTED, false);
        graphics.fill(left + 16, top + 36, left + width - 16, top + 37, 0x855B2679);

        AuctionUi.drawCard(graphics, innerX, searchY, searchWidth, 28);

        String pageLabel = (this.displayPage + 1) + " / " + this.pageCount;
        int pageWidth = AuctionUi.width(pageLabel);
        AuctionUi.drawText(graphics, pageLabel, left + width - 18 - pageWidth,
                top + height - 51, AuctionUi.DIM, false);

        if (this.filteredItems.isEmpty()) {
            AuctionUi.drawText(graphics, "No items found", innerX + 3, top + 91,
                    AuctionUi.MUTED, false);
        }

        super.extractRenderState(graphics, mouseX, mouseY, delta);

        if (this.searchField != null && this.searchField.getValue().isEmpty()) {
            AuctionUi.drawText(graphics, "Enter the item's name",
                    innerX + 9, searchY + 10, AuctionUi.DIM, false);
        }
    }
}

package dev.streamauction;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PaymentParserTest {
    @Test
    void parsesDonutStylePaymentLineWithSeparatedDollarAndSuffix() {
        var result = PaymentParser.parseServerPayment("a9zdd paid you $ 5M.");
        assertTrue(result.isPresent());
        assertEquals("a9zdd", result.get().playerName());
        assertEquals(5_000_000L, result.get().amount());
    }

    @Test
    void parsesGroupedAndDecimalAmounts() {
        assertEquals(1_250_000L, PaymentParser.parseServerPayment("Player_2 paid you $1.25M!").orElseThrow().amount());
        assertEquals(2_500L, PaymentParser.parseServerPayment(".Guest paid you $2,500.").orElseThrow().amount());
    }

    @Test
    void parsesUiShorthand() {
        assertEquals(1_500_000L, PaymentParser.parseAmountInput("1.5m").orElseThrow());
        assertEquals(250_000L, PaymentParser.parseAmountInput("$250k").orElseThrow());
        assertEquals(0L, PaymentParser.parseAmountInput("0").orElseThrow());
    }

    @Test
    void rejectsNonPaymentTextAndInvalidValues() {
        assertTrue(PaymentParser.parseServerPayment("a9zdd paid them $ 5M").isEmpty());
        assertTrue(PaymentParser.parseServerPayment("hello everyone").isEmpty());
        assertTrue(PaymentParser.parseAmountInput("not a number").isEmpty());
    }
}

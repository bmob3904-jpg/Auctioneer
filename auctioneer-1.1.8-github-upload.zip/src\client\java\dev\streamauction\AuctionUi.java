package dev.streamauction;

import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.resources.Identifier;

public final class AuctionUi {
    public static final int PANEL = 0xD8090611;
    public static final int PANEL_INNER = 0x76110A1A;
    public static final int CARD = 0xA80E0916;
    public static final int CARD_HOVER = 0xD91D1030;
    public static final int PURPLE = 0xFFEAD8FF;
    public static final int PURPLE_BRIGHT = 0xFFF044FF;
    public static final int PURPLE_DEEP = 0xFF9D35E8;
    public static final int WHITE = 0xFFFFFAFF;
    public static final int MUTED = 0xFFB6A5C7;
    public static final int DIM = 0xFF73647D;
    public static final int LINE = 0xFF2B1838;
    public static final int BORDER = 0xFF673281;
    public static final int GREEN = 0xFFE15AFF;
    public static final int AMBER = 0xFFFFB5F8;
    public static final int RED = 0xFFFF739D;

    private static final Identifier MODERN_FONT_ID =
            Identifier.fromNamespaceAndPath("streamauction", "modern");

    private AuctionUi() { }

    /**
     * Use Minecraft's normal renderer, with the bundled font selected on each text component.
     * This lets the resource manager load the TTF normally and safely falls back if unavailable.
     */
    public static Font font() {
        return Minecraft.getInstance().font;
    }

    public static Component component(String value) {
        return Component.literal(value == null ? "" : value)
                .withStyle(style -> style.withFont(new FontDescription.Resource(MODERN_FONT_ID)));
    }

    public static void drawText(GuiGraphicsExtractor graphics, String value,
                                int x, int y, int color, boolean shadow) {
        graphics.text(Minecraft.getInstance().font, component(value), x, y, color, shadow);
    }

    public static void drawCenteredText(GuiGraphicsExtractor graphics, String value,
                                        int centerX, int y, int color) {
        int textWidth = width(value);
        drawText(graphics, value, centerX - textWidth / 2, y, color, false);
    }

    public static int width(String value) {
        return Minecraft.getInstance().font.width(component(value));
    }

    public static void drawBackdrop(GuiGraphicsExtractor graphics, int width, int height) {
        graphics.fill(0, 0, width, height, 0x95000008);
        graphics.fill(0, 0, width, 1, 0xA8D13BFF);
        graphics.fill(0, 1, width, 2, 0x354E1A65);
    }

    public static void drawPanel(GuiGraphicsExtractor graphics, int x, int y, int width, int height) {
        roundedFill(graphics, x - 3, y - 2, width + 6, height + 4, 13, 0x206C20B6);
        roundedFill(graphics, x - 1, y - 1, width + 2, height + 2, 12, 0x925D2A80);
        roundedFill(graphics, x, y, width, height, 11, PANEL);
        roundedFill(graphics, x + 2, y + 2, width - 4, height - 4, 9, PANEL_INNER);
        // A very subtle glass reflection and inner edge, not a thick Minecraft-style frame.
        roundedFill(graphics, x + 18, y + 2, width - 36, 1, 1, 0x70D94BFF);
        roundedFill(graphics, x + 20, y + 4, width - 40, 1, 1, 0x1BFFFFFF);
        roundedFill(graphics, x + 2, y + 14, 1, Math.max(1, height - 28), 1, 0x267B32A6);
    }

    public static void drawCard(GuiGraphicsExtractor graphics, int x, int y, int width, int height) {
        roundedFill(graphics, x, y + 1, width, height, 7, 0x8B281747);
        roundedFill(graphics, x + 1, y, width - 2, height, 6, BORDER);
        roundedFill(graphics, x + 2, y + 1, width - 4, height - 2, 5, CARD);
        roundedFill(graphics, x + 10, y + 1, width - 20, 1, 1, 0x5CCF3AFF);
    }

    public static void drawButton(GuiGraphicsExtractor graphics, int x, int y, int width, int height,
                                  int accent, boolean primary, boolean hovered) {
        int border = hovered ? 0xFFF05AFF : primary ? 0xD6B54BEB : 0x8B59366D;
        int fill = hovered ? 0xF0211034 : primary ? 0xD8140A22 : 0xB3090612;
        roundedFill(graphics, x, y + 1, width, height, 7, 0x4F030208);
        roundedFill(graphics, x, y, width, height, 7, border);
        roundedFill(graphics, x + 1, y + 1, width - 2, height - 2, 6, fill);
        roundedFill(graphics, x + 8, y + 1, width - 16, 1, 1,
                hovered ? 0xBDEB50FF : 0x359D54B8);
        if (primary) {
            roundedFill(graphics, x + 3, y + 6, 2, Math.max(1, height - 12), 1, accent);
            roundedFill(graphics, x + 10, y + height - 3, width - 20, 1, 1, 0x88D943FF);
        }
    }

    private static void roundedFill(GuiGraphicsExtractor graphics, int x, int y, int width, int height,
                                    int radius, int color) {
        if (width <= 0 || height <= 0) return;
        int r = Math.max(0, Math.min(radius, Math.min(width / 2, height / 2)));
        if (r == 0) {
            graphics.fill(x, y, x + width, y + height, color);
            return;
        }
        graphics.fill(x + r, y, x + width - r, y + height, color);
        graphics.fill(x, y + r, x + width, y + height - r, color);
        int rr = r * r;
        for (int row = 0; row < r; row++) {
            int dy = r - row;
            int inset = r - (int) Math.floor(Math.sqrt(Math.max(0, rr - dy * dy)));
            if (inset > 0) {
                graphics.fill(x + inset, y + row, x + width - inset, y + row + 1, color);
                graphics.fill(x + inset, y + height - row - 1,
                        x + width - inset, y + height - row, color);
            }
        }
    }

    public static void drawTimerRing(GuiGraphicsExtractor graphics, int centerX, int centerY,
                                     int radius, double progress, int accent) {
        int segments = Math.max(72, radius * 7);
        double clamped = Math.max(0.0, Math.min(1.0, progress));
        int activeSegments = (int) Math.ceil(segments * clamped);
        for (int i = 0; i < segments; i++) {
            double angle = -Math.PI / 2.0 + Math.PI * 2.0 * i / segments;
            int px = centerX + (int) Math.round(Math.cos(angle) * radius);
            int py = centerY + (int) Math.round(Math.sin(angle) * radius);
            int color = i < activeSegments ? accent : LINE;
            graphics.fill(px - 1, py - 1, px + 2, py + 2, color);
        }
    }

    public static void drawIconDisc(GuiGraphicsExtractor graphics, int centerX, int centerY,
                                    int radius, int color) {
        int r = Math.max(2, radius);
        for (int dy = -r; dy <= r; dy++) {
            int span = (int) Math.floor(Math.sqrt((double) r * r - (double) dy * dy));
            graphics.fill(centerX - span, centerY + dy, centerX + span + 1, centerY + dy + 1, color);
        }
    }

    public static void drawPill(GuiGraphicsExtractor graphics, Font ignored, String label,
                                int right, int y, int color) {
        int width = width(label) + 19;
        int left = right - width;
        roundedFill(graphics, left, y, width, 17, 8, 0xB6652A83);
        roundedFill(graphics, left + 1, y + 1, width - 2, 15, 7, 0xD8090612);
        roundedFill(graphics, left + 7, y + 7, 3, 3, 1, color);
        drawText(graphics, label, left + 14, y + 5, color, false);
    }

    public static String formatTime(long seconds) {
        long safe = Math.max(0L, seconds);
        long hours = safe / 3600L;
        long minutes = (safe % 3600L) / 60L;
        long secs = safe % 60L;
        return hours > 0
                ? String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, secs)
                : String.format(Locale.ROOT, "%02d:%02d", minutes, secs);
    }

    public static int timerColor(long remaining) {
        if (remaining <= 5L) return RED;
        if (remaining <= 10L) return AMBER;
        return PURPLE;
    }

    public static String clip(String value, int maxWidth) {
        if (value == null || maxWidth <= 0) return "";
        String result = value;
        while (!result.isEmpty() && width(result) > maxWidth) {
            result = result.substring(0, result.length() - 1);
        }
        return result;
    }
}

package dev.streamauction;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ItemSelectionPolicyTest {
    @Test
    void hidesSpawnEggsForEveryEntity() {
        assertFalse(ItemSelectionPolicy.isSelectable("minecraft:zombie_spawn_egg"));
        assertFalse(ItemSelectionPolicy.isSelectable("minecraft:allay_spawn_egg"));
        assertFalse(ItemSelectionPolicy.isSelectable("examplemod:custom_mob_spawn_egg"));
    }

    @Test
    void hidesOperatorOnlyBlocksAndTools() {
        assertFalse(ItemSelectionPolicy.isSelectable("minecraft:command_block"));
        assertFalse(ItemSelectionPolicy.isSelectable("minecraft:barrier"));
        assertFalse(ItemSelectionPolicy.isSelectable("minecraft:debug_stick"));
        assertFalse(ItemSelectionPolicy.isSelectable("minecraft:spawner"));
    }

    @Test
    void keepsNormalAuctionItemsSelectable() {
        assertTrue(ItemSelectionPolicy.isSelectable("minecraft:diamond"));
        assertTrue(ItemSelectionPolicy.isSelectable("minecraft:enchanted_golden_apple"));
        assertTrue(ItemSelectionPolicy.isSelectable("minecraft:bow"));
    }

    @Test
    void rejectsEmptyIdsAndAir() {
        assertFalse(ItemSelectionPolicy.isSelectable(null));
        assertFalse(ItemSelectionPolicy.isSelectable(" "));
        assertFalse(ItemSelectionPolicy.isSelectable("minecraft:air"));
    }
}

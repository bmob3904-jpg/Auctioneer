/*
 * Decompiled with CFR 0.152.
 */
package dev.streamauction;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class PaymentLedger {
    private final Map<String, Bidder> bidders = new LinkedHashMap<String, Bidder>();
    private int paymentCount;

    PaymentLedger() {
    }

    synchronized boolean record(boolean auctionActive, String playerName, long amount, long timestamp) {
        return this.record(auctionActive, playerName, amount, 0L, timestamp);
    }

    synchronized boolean record(boolean auctionActive, String playerName, long amount, long minimumAmount, long timestamp) {
        if (!auctionActive || playerName == null || playerName.isBlank() || amount <= 0L || amount < Math.max(0L, minimumAmount)) {
            return false;
        }
        String shownName = playerName.trim();
        String key = shownName.toLowerCase(Locale.ROOT);
        Bidder bidder = this.bidders.computeIfAbsent(key, ignored -> new Bidder(shownName));
        bidder.name = shownName;
        bidder.total = PaymentLedger.saturatedAdd(bidder.total, amount);
        if (bidder.paymentCount < Integer.MAX_VALUE) {
            ++bidder.paymentCount;
        }
        bidder.lastPaymentAt = timestamp;
        bidder.lastPaymentAmount = amount;
        if (this.paymentCount < Integer.MAX_VALUE) {
            ++this.paymentCount;
        }
        return true;
    }

    synchronized void clear() {
        this.bidders.clear();
        this.paymentCount = 0;
    }

    synchronized void restore(Map<String, Bidder> storedBidders, int storedPaymentCount) {
        this.bidders.clear();
        this.paymentCount = Math.max(0, storedPaymentCount);
        if (storedBidders == null) {
            return;
        }
        storedBidders.forEach((key, value) -> {
            if (key == null || value == null || value.name == null || value.name.isBlank() || value.total < 0L) {
                return;
            }
            String normalized = value.name.trim().toLowerCase(Locale.ROOT);
            Bidder copy = new Bidder(value.name.trim());
            copy.total = value.total;
            copy.paymentCount = Math.max(0, value.paymentCount);
            copy.lastPaymentAt = Math.max(0L, value.lastPaymentAt);
            copy.lastPaymentAmount = Math.max(0L, value.lastPaymentAmount);
            this.bidders.put(normalized, copy);
        });
    }

    synchronized Map<String, Bidder> entriesForSave() {
        LinkedHashMap<String, Bidder> copy = new LinkedHashMap<String, Bidder>();
        this.bidders.forEach((key, value) -> copy.put((String)key, value.copy()));
        return copy;
    }

    synchronized int paymentCount() {
        return this.paymentCount;
    }

    synchronized int bidderCount() {
        return this.bidders.size();
    }

    synchronized List<EntrySnapshot> leaderboard() {
        ArrayList<EntrySnapshot> ranking = new ArrayList<EntrySnapshot>();
        for (Bidder bidder : this.bidders.values()) {
            ranking.add(new EntrySnapshot(bidder.name, bidder.total, bidder.paymentCount, bidder.lastPaymentAt, bidder.lastPaymentAmount));
        }
        ranking.sort(Comparator.comparingLong(EntrySnapshot::total).reversed().thenComparing(Comparator.comparingLong(EntrySnapshot::lastPaymentAt).reversed()).thenComparing(EntrySnapshot::name, String.CASE_INSENSITIVE_ORDER));
        return List.copyOf(ranking);
    }

    synchronized List<EntrySnapshot> tiedLeaders() {
        List<EntrySnapshot> ranking = this.leaderboard();
        if (ranking.isEmpty()) {
            return List.of();
        }
        long top = ranking.get(0).total();
        return ranking.stream().takeWhile(entry -> entry.total() == top).toList();
    }

    private static long saturatedAdd(long first, long second) {
        try {
            return Math.addExact(first, second);
        }
        catch (ArithmeticException ignored) {
            return Long.MAX_VALUE;
        }
    }

    static final class Bidder {
        private String name;
        private long total;
        private int paymentCount;
        private long lastPaymentAt;
        private long lastPaymentAmount;

        private Bidder() {
        }

        private Bidder(String name) {
            this.name = name;
        }

        private Bidder copy() {
            Bidder copy = new Bidder(this.name);
            copy.total = this.total;
            copy.paymentCount = this.paymentCount;
            copy.lastPaymentAt = this.lastPaymentAt;
            copy.lastPaymentAmount = this.lastPaymentAmount;
            return copy;
        }
    }

    record EntrySnapshot(String name, long total, int paymentCount, long lastPaymentAt, long lastPaymentAmount) {
    }
}


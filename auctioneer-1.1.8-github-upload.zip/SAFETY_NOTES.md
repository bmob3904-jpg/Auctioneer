# Safety notes - Auctioneer 1.1.8

- Client-side and read-only: listens to Fabric's server/system message event and parses payment notices only.
- Ignores ordinary player-written chat.
- No chat/command sending, automated game input, inventory manipulation, web requests, or authentication-token access.
- Main controls, item picker, and HUD are drawn in Minecraft. No external desktop window is launched.
- Uses Minecraft item textures in the picker, selected-item preview, and HUD; the selected-item preview includes a circular countdown ring.
- The optional minimum payment filters smaller payments before they enter totals.
- Settings and results are stored locally in `config/streamauction/state.json`.
- Search picker excludes spawn eggs and operator-only items.
- Bundled Exo 2 font and its SIL Open Font License are included; the Minecraft font provider refers to `streamauction:exo2.ttf`.
- The interface title is Auctioneer. The former upper-left "SA" badge is removed. The HUD watermark remains small and subdued at bottom-left.
- DonutSMP's official rules are at https://rules.donutsmp.net/. The rules do not guarantee an exemption for passive streamer auction tracking; ask staff before using it on the server.
- Build target: Java 25, Gradle 9.7.0, Fabric Loom 1.18.4, Minecraft 26.2, Fabric Loader 0.19.5, Fabric API 0.161.0+26.2.

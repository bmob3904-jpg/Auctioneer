package dev.streamauction;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Strict, side-effect-free parser for the server-generated "paid you" system line.
 * The caller must only pass messages from Fabric's GAME/system-message event, never player chat.
 */
public final class PaymentParser {
    private static final Pattern PAYMENT_LINE = Pattern.compile(
            "(?i)(?:^|\\s)([a-z0-9_.]{1,16})\\s+paid\\s+you\\s+\\$?\\s*" +
            "([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*([kmbt]?)\\s*(?=[.!?\\s]|$)"
    );
    private static final Pattern AMOUNT_VALUE = Pattern.compile(
            "(?i)^\\s*\\$?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*([kmbt]?)\\s*$"
    );

    private PaymentParser() { }

    public record ParsedPayment(String playerName, long amount) { }

    public static Optional<ParsedPayment> parseServerPayment(String message) {
        if (message == null || message.isBlank()) return Optional.empty();
        Matcher matcher = PAYMENT_LINE.matcher(message.trim());
        if (!matcher.find()) return Optional.empty();

        try {
            long amount = parseAmountParts(matcher.group(2), matcher.group(3));
            if (amount <= 0) return Optional.empty();
            return Optional.of(new ParsedPayment(matcher.group(1), amount));
        } catch (RuntimeException ignored) {
            return Optional.empty();
        }
    }

    /** Parses UI amounts like 250k, 1.5m, $2,000, or 900000. */
    public static Optional<Long> parseAmountInput(String value) {
        if (value == null || value.isBlank()) return Optional.of(0L);
        Matcher matcher = AMOUNT_VALUE.matcher(value);
        if (!matcher.matches()) return Optional.empty();
        try {
            return Optional.of(parseAmountParts(matcher.group(1), matcher.group(2)));
        } catch (RuntimeException ignored) {
            return Optional.empty();
        }
    }

    private static long parseAmountParts(String number, String suffix) {
        BigDecimal base = new BigDecimal(number.replace(",", ""));
        BigDecimal multiplier = switch (suffix == null ? "" : suffix.toLowerCase(Locale.ROOT)) {
            case "k" -> BigDecimal.valueOf(1_000L);
            case "m" -> BigDecimal.valueOf(1_000_000L);
            case "b" -> BigDecimal.valueOf(1_000_000_000L);
            case "t" -> BigDecimal.valueOf(1_000_000_000_000L);
            default -> BigDecimal.ONE;
        };
        BigDecimal result = base.multiply(multiplier).setScale(0, RoundingMode.HALF_UP);
        if (result.signum() < 0 || result.compareTo(BigDecimal.valueOf(Long.MAX_VALUE)) > 0) {
            throw new ArithmeticException("Amount out of range");
        }
        return result.longValueExact();
    }
}

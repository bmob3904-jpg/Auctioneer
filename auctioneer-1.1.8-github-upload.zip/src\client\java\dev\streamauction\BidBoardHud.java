package dev.streamauction;

import java.util.List;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;

public final class BidBoardHud {
    private static final int PANEL_WIDTH = 252;
    private static final int PANEL_HEIGHT = 94;

    private BidBoardHud() { }

    public static void render(GuiGraphicsExtractor graphics, DeltaTracker ignored) {
        if (!AuctionManager.isHudVisible()) return;
        if (!AuctionManager.isActive() && !AuctionManager.isFinished()) return;

        Minecraft minecraft = Minecraft.getInstance();
        int x = 12;
        int y = 30;
        int right = x + PANEL_WIDTH;
        AuctionUi.drawPanel(graphics, x, y, PANEL_WIDTH, PANEL_HEIGHT);

        int centerX = x + 29;
        int centerY = y + 29;
        long remaining = AuctionManager.isActive() ? AuctionManager.secondsRemaining() : 0L;
        double progress = AuctionManager.isActive()
                ? (double) remaining / Math.max(1, AuctionManager.durationSeconds()) : 0.0;

        AuctionUi.drawTimerRing(graphics, centerX, centerY, 18, progress,
                AuctionManager.isActive() ? AuctionUi.timerColor(remaining) : AuctionUi.LINE);
        AuctionUi.drawIconDisc(graphics, centerX, centerY, 13, 0xF007040F);
        ItemStack stack = AuctionManager.selectedItem().getDefaultInstance();
        graphics.item(stack, centerX - 8, centerY - 8);

        int textX = x + 55;
        int textWidth = PANEL_WIDTH - (textX - x) - 17;
        AuctionUi.drawText(graphics, AuctionUi.clip(AuctionManager.selectedItemName(), textWidth),
                textX, y + 18, AuctionUi.WHITE, true);
        AuctionUi.drawText(graphics, AuctionUi.formatTime(remaining), textX, y + 33,
                AuctionUi.timerColor(AuctionManager.isActive() ? remaining : 0L), true);

        graphics.fill(x + 13, y + 53, right - 13, y + 54, 0x70452A58);

        List<AuctionManager.BidderSnapshot> leaders = AuctionManager.tiedLeaders();
        String leaderName;
        String amount = "";
        if (AuctionManager.wasInterrupted()) {
            leaderName = "Stopped after restart";
        } else if (leaders.isEmpty()) {
            leaderName = AuctionManager.isActive() ? "Waiting for bids" : "No bids";
        } else {
            leaderName = leaders.size() > 1 ? "TIE" : leaders.getFirst().name();
            amount = AuctionManager.formatMoney(leaders.getFirst().total());
        }

        int amountWidth = AuctionUi.width(amount);
        int leaderWidth = PANEL_WIDTH - 28 - (amount.isEmpty() ? 0 : amountWidth + 12);
        int leaderColor = leaders.isEmpty() || AuctionManager.wasInterrupted()
                ? AuctionUi.DIM : AuctionUi.PURPLE;
        AuctionUi.drawText(graphics, AuctionUi.clip(leaderName, leaderWidth),
                x + 14, y + 63, leaderColor, true);
        if (!amount.isEmpty()) {
            AuctionUi.drawText(graphics, amount, right - 14 - amountWidth,
                    y + 63, AuctionUi.PURPLE_BRIGHT, true);
        }

        // Small and subdued: an ownership mark, not a headline.
        graphics.pose().pushMatrix();
        graphics.pose().translate(x + 10, y + PANEL_HEIGHT - 7);
        graphics.pose().scale(0.58f, 0.58f);
        AuctionUi.drawText(graphics, "Made by SlachlanS", 0, 0, 0xFF62506D, false);
        graphics.pose().popMatrix();
    }
}

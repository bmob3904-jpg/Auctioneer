package dev.streamauction;

import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

final class ModernButton extends AbstractWidget {
    private final Runnable action;
    private final int accent;
    private final boolean primary;
    private final String subtitle;
    private final ItemStack icon;
    private final boolean timerRing;
    private final DoubleSupplier progress;
    private final Supplier<String> rightText;

    ModernButton(int x, int y, int width, int height, String label, int accent,
                 boolean primary, Runnable action) {
        this(x, y, width, height, label, null, null, false, null, null, accent, primary, action);
    }

    ModernButton(int x, int y, int width, int height, String label, String subtitle,
                 ItemStack icon, boolean timerRing, DoubleSupplier progress,
                 Supplier<String> rightText, int accent, boolean primary, Runnable action) {
        super(x, y, width, height, Component.literal(label == null ? "" : label));
        this.action = action;
        this.accent = accent;
        this.primary = primary;
        this.subtitle = subtitle;
        this.icon = icon;
        this.timerRing = timerRing;
        this.progress = progress;
        this.rightText = rightText;
    }

    @Override
    protected void extractWidgetRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        int x = this.getX();
        int y = this.getY();
        int right = x + this.width;
        int bottom = y + this.height;
        boolean hovered = this.isHoveredOrFocused();

        AuctionUi.drawButton(graphics, x, y, this.width, this.height, this.accent, this.primary, hovered);
        Minecraft minecraft = Minecraft.getInstance();
        int centerY = y + this.height / 2;

        if (this.icon != null && !this.icon.isEmpty()) {
            int centerX = x + (this.timerRing ? Math.min(27, this.height / 2) : Math.min(16, this.height / 2));
            int radius = this.timerRing
                    ? Math.max(9, Math.min(20, this.height / 2 - 5))
                    : Math.max(5, Math.min(10, this.height / 2 - 3));

            if (this.timerRing) {
                double fraction = this.progress == null ? 1.0 : this.progress.getAsDouble();
                AuctionUi.drawTimerRing(graphics, centerX, centerY, radius, fraction, this.accent);
                AuctionUi.drawIconDisc(graphics, centerX, centerY, Math.max(4, radius - 4), 0xF00D0819);
            } else {
                AuctionUi.drawIconDisc(graphics, centerX, centerY, radius, 0xD5140D20);
            }
            graphics.item(this.icon, centerX - 8, centerY - 8);

            int textX = x + (this.timerRing ? 54 : 32);
            int reservedRight = this.rightText == null ? 12 : 84;
            int textWidth = Math.max(0, right - textX - reservedRight);
            String title = AuctionUi.clip(this.getMessage().getString(), textWidth);
            if (this.subtitle == null || this.subtitle.isBlank()) {
                AuctionUi.drawText(graphics, title, textX, centerY - 4, AuctionUi.WHITE, true);
            } else {
                AuctionUi.drawText(graphics, title, textX, centerY - 10, AuctionUi.WHITE, true);
                AuctionUi.drawText(graphics, AuctionUi.clip(this.subtitle, textWidth),
                        textX, centerY + 5, AuctionUi.MUTED, false);
            }

            if (this.rightText != null) {
                String value = this.rightText.get();
                int valueWidth = AuctionUi.width(value);
                int valueX = right - 13 - valueWidth;
                int valueColor = AuctionUi.timerColor(AuctionManager.isActive()
                        ? AuctionManager.secondsRemaining()
                        : AuctionManager.durationSeconds());
                AuctionUi.drawText(graphics, value, valueX, centerY - 7, valueColor, true);

            }
        } else {
            AuctionUi.drawCenteredText(graphics, this.getMessage().getString(), x + this.width / 2,
                    centerY - 4, this.primary ? AuctionUi.WHITE : (hovered ? AuctionUi.PURPLE : AuctionUi.MUTED));
        }
    }

    @Override
    public void onClick(MouseButtonEvent event, boolean doubleClick) {
        super.onClick(event, doubleClick);
        if (this.active && this.visible && this.action != null) {
            playButtonClickSound((SoundManager) Minecraft.getInstance().getSoundManager());
            this.action.run();
        }
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput narration) {
        this.defaultButtonNarrationText(narration);
    }
}

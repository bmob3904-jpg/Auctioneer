package dev.streamauction;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public final class BidBoardClient implements ClientModInitializer {
    public static final String MOD_ID = "streamauction";
    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "controls"));
    private static final KeyMapping OPEN_MENU = KeyMappingHelper.registerKeyMapping(
            new KeyMapping("key.streamauction.open_menu", InputConstants.Type.KEYSYM, 344, CATEGORY));

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitializeClient() {
        AuctionManager.load();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            AuctionManager.tick();
            while (OPEN_MENU.consumeClick()) {
                if (client.player == null) continue;
                client.gui.setScreen(new AuctionMenuScreen(client.gui.screen()));
            }
        });
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            PaymentParser.parseServerPayment(message.getString())
                    .ifPresent(payment -> AuctionManager.recordPayment(payment.playerName(), payment.amount()));
        });
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                BidBoardClient.id("auction_hud"),
                BidBoardHud::render);
    }
}

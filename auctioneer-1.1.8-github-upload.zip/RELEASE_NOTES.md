﻿# Auctioneer 1.1.8 release notes

- Returns the interface to Minecraft's in-game UI.
- Removes the old SA badge and renames the interface Auctioneer.
- Restores the Minecraft item textures in the menu, picker and HUD.
- Restores the circular countdown ring.
- Removes the left-side Items tab; choose an item by clicking its preview.
- Keeps the highest-bidder-only HUD, optional minimum payment, timer, HUD toggle and subtle watermark.
- Minecraft 26.2 / Fabric Loader 0.19.5+ / Java 25.

Install the JAR in your Fabric mods folder. Remove older Auctioneer / Stream Auction Board JARs first.

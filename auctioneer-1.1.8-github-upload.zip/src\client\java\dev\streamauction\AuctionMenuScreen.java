package dev.streamauction;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

public final class AuctionMenuScreen extends Screen {
    private static final int PANEL_WIDTH = 420;
    private static final int PANEL_HEIGHT = 226;

    private final Screen parent;
    private String message;
    private EditBox durationField;
    private EditBox minimumPaymentField;

    public AuctionMenuScreen(Screen parent) {
        this(parent, "");
    }

    public AuctionMenuScreen(Screen parent, String message) {
        super(Component.literal("Auctioneer"));
        this.parent = parent;
        this.message = message == null ? "" : message;
    }

    private int panelWidth() { return Math.max(1, Math.min(PANEL_WIDTH, this.width - 16)); }
    private int panelHeight() { return Math.max(1, Math.min(PANEL_HEIGHT, this.height - 16)); }
    private int left() { return (this.width - this.panelWidth()) / 2; }
    private int top() { return (this.height - this.panelHeight()) / 2; }

    @Override
    protected void init() {
        int left = this.left();
        int top = this.top();
        int width = this.panelWidth();
        boolean active = AuctionManager.isActive();

        this.addRenderableWidget(new ModernButton(left + width - 32, top + 10, 22, 22,
                "X", AuctionUi.MUTED, false, this::closeToParent));

        // Textured Minecraft item, countdown ring, and the selected item's name.
        this.addRenderableWidget(new ModernButton(left + 14, top + 42, width - 28, 56,
                AuctionManager.selectedItemName(), null,
                AuctionManager.selectedItem().getDefaultInstance(), true,
                () -> AuctionManager.isActive()
                        ? (double) AuctionManager.secondsRemaining() / Math.max(1, AuctionManager.durationSeconds())
                        : 1.0,
                () -> AuctionUi.formatTime(AuctionManager.isActive()
                        ? AuctionManager.secondsRemaining() : AuctionManager.durationSeconds()),
                AuctionUi.PURPLE_BRIGHT, false,
                () -> this.minecraft.gui.setScreen(new ItemPickerScreen(this, "", 0))));

        int innerX = left + 14;
        int innerWidth = width - 28;
        int durationWidth = 104;
        int fieldGap = 10;
        int minX = innerX + durationWidth + fieldGap;
        int minWidth = innerWidth - durationWidth - fieldGap;

        this.durationField = new EditBox(AuctionUi.font(), innerX + 9, top + 128,
                durationWidth - 18, 19, Component.literal("Auction duration in seconds"));
        this.durationField.setMaxLength(5);
        this.durationField.setValue(Integer.toString(AuctionManager.durationSeconds()));
        this.durationField.setEditable(!active);
        this.durationField.setBordered(false);
        this.durationField.setTextColor(AuctionUi.WHITE);
        this.durationField.setTextColorUneditable(AuctionUi.DIM);
        this.addRenderableWidget(this.durationField);

        this.minimumPaymentField = new EditBox(AuctionUi.font(), minX + 9, top + 128,
                minWidth - 18, 19, Component.literal("Optional minimum payment"));
        this.minimumPaymentField.setMaxLength(24);
        this.minimumPaymentField.setValue(AuctionManager.minimumPaymentAmount() > 0L
                ? AuctionManager.formatMoney(AuctionManager.minimumPaymentAmount()) : "");
        this.minimumPaymentField.setEditable(!active);
        this.minimumPaymentField.setBordered(false);
        this.minimumPaymentField.setTextColor(AuctionUi.WHITE);
        this.minimumPaymentField.setTextColorUneditable(AuctionUi.DIM);
        this.addRenderableWidget(this.minimumPaymentField);

        int buttonY = top + 164;
        int startWidth = innerWidth - 124;
        this.addRenderableWidget(new ModernButton(innerX, buttonY, startWidth, 30,
                active ? "END AUCTION" : "START AUCTION",
                active ? AuctionUi.RED : AuctionUi.PURPLE_BRIGHT, true, this::handleAuctionButton));

        this.addRenderableWidget(new ModernButton(innerX + startWidth + 10, buttonY, 114, 30,
                AuctionManager.isHudVisible() ? "HUD ON" : "HUD OFF",
                AuctionManager.isHudVisible() ? AuctionUi.PURPLE_BRIGHT : AuctionUi.MUTED, false, () -> {
                    AuctionManager.toggleHud();
                    this.minecraft.gui.setScreen(new AuctionMenuScreen(this.parent, this.message));
                }));
    }

    private void handleAuctionButton() {
        if (AuctionManager.isActive()) {
            AuctionManager.endAuction();
            this.minecraft.gui.setScreen(new AuctionMenuScreen(this.parent, "Auction ended."));
            return;
        }

        int seconds;
        try {
            seconds = Integer.parseInt(this.durationField.getValue().trim());
        } catch (NumberFormatException exception) {
            this.message = "Enter 5 to 3,600 seconds.";
            return;
        }
        if (seconds < 5 || seconds > 3600) {
            this.message = "Use 5 to 3,600 seconds.";
            return;
        }

        var minimumResult = PaymentParser.parseAmountInput(this.minimumPaymentField.getValue());
        if (minimumResult.isEmpty()) {
            this.message = "Enter a valid minimum (e.g. 250k), or leave blank.";
            return;
        }

        AuctionManager.setDurationSeconds(seconds);
        AuctionManager.setMinimumPaymentAmount(minimumResult.get());
        AuctionManager.startAuction();
        this.minecraft.gui.setScreen(new AuctionMenuScreen(this.parent, "Auction started."));
    }

    private void closeToParent() {
        if (this.minecraft != null) this.minecraft.gui.setScreen(this.parent);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == 256) {
            this.closeToParent();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean shouldCloseOnEsc() { return true; }

    @Override
    public void onClose() { this.closeToParent(); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        int left = this.left();
        int top = this.top();
        int width = this.panelWidth();
        int height = this.panelHeight();
        int innerX = left + 14;
        int innerWidth = width - 28;
        int durationWidth = 104;
        int minX = innerX + durationWidth + 10;
        int minWidth = innerWidth - durationWidth - 10;

        AuctionUi.drawBackdrop(graphics, this.width, this.height);
        AuctionUi.drawPanel(graphics, left, top, width, height);

        AuctionUi.drawText(graphics, "AUCTIONEER", left + 18, top + 14, AuctionUi.WHITE, true);
        String status = AuctionManager.wasInterrupted() ? "STOPPED"
                : AuctionManager.isActive() ? "LIVE"
                : AuctionManager.isFinished() ? "ENDED" : "READY";
        int statusColor = AuctionManager.wasInterrupted() ? AuctionUi.RED
                : AuctionManager.isActive() ? AuctionUi.PURPLE_BRIGHT
                : AuctionManager.isFinished() ? AuctionUi.MUTED : AuctionUi.PURPLE;
        AuctionUi.drawPill(graphics, AuctionUi.font(), status, left + width - 43, top + 11, statusColor);
        graphics.fill(left + 16, top + 34, left + width - 16, top + 35, 0x855B2679);

        AuctionUi.drawText(graphics, "SELECTED ITEM", innerX + 2, top + 36, AuctionUi.MUTED, false);
        AuctionUi.drawText(graphics, "DURATION", innerX + 1, top + 111, AuctionUi.MUTED, false);
        AuctionUi.drawText(graphics, "OPTIONAL MIN PAYMENT", minX + 1, top + 111, AuctionUi.MUTED, false);

        AuctionUi.drawCard(graphics, innerX, top + 122, durationWidth, 32);
        AuctionUi.drawCard(graphics, minX, top + 122, minWidth, 32);

        if (this.message != null && !this.message.isBlank()) {
            int color = this.message.startsWith("Use") || this.message.startsWith("Enter")
                    ? AuctionUi.AMBER : AuctionUi.MUTED;
            AuctionUi.drawText(graphics, AuctionUi.clip(this.message, innerWidth),
                    innerX + 1, top + height - 10, color, false);
        }
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }
}

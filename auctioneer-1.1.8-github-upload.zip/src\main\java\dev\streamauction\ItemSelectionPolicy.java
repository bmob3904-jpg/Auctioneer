package dev.streamauction;

import java.util.Locale;
import java.util.Set;

/** Filters non-tradeable or operator-only items from the stream auction picker. */
public final class ItemSelectionPolicy {
    private static final Set<String> HIDDEN_IDS = Set.of(
            "minecraft:barrier",
            "minecraft:command_block",
            "minecraft:chain_command_block",
            "minecraft:repeating_command_block",
            "minecraft:command_block_minecart",
            "minecraft:debug_stick",
            "minecraft:jigsaw",
            "minecraft:structure_block",
            "minecraft:structure_void",
            "minecraft:light",
            "minecraft:knowledge_book",
            "minecraft:spawner"
    );

    private ItemSelectionPolicy() { }

    public static boolean isSelectable(String itemId) {
        if (itemId == null || itemId.isBlank()) return false;
        String id = itemId.trim().toLowerCase(Locale.ROOT);
        if (id.endsWith(":air") || id.endsWith("_spawn_egg")) return false;
        return !HIDDEN_IDS.contains(id);
    }
}
